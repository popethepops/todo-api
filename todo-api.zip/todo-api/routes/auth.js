const express = require('express');
const router = express.Router();
const { register } = require('../controllers/authController');

console.log('🔥 Hitting /auth routes');
console.log('👉 Register function is:', register);

router.post('/register', (req, res) => {
    console.log('📩 POST /auth/register');
    console.log('📬 Body:', req.body);
    res.json({ message: 'received' });
  });  

module.exports = router;
