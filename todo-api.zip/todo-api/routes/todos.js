const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const {
  createTodo, getTodos, getTodoById, updateTodo, deleteTodo
} = require('../controllers/todoController');

router.post('/items', auth, createTodo);
router.get('/items', auth, getTodos);
router.get('/items/:id', auth, getTodoById);
router.put('/items/:id', auth, updateTodo);
router.delete('/items/:id', auth, deleteTodo);

module.exports = router;
