const Todo = require('../models/Todo');

exports.createTodo = async (req, res) => {
  const todo = await Todo.create({ ...req.body, user: req.user._id });
  res.json(todo);
};

exports.getTodos = async (req, res) => {
  const { page = 1, limit = 5 } = req.query;
  const todos = await Todo.find({ user: req.user._id })
    .skip((page - 1) * limit).limit(Number(limit));
  const total = await Todo.countDocuments({ user: req.user._id });
  res.json({ total, pages: Math.ceil(total / limit), todos });
};

exports.getTodoById = async (req, res) => {
  const todo = await Todo.findOne({ _id: req.params.id, user: req.user._id });
  if (!todo) return res.status(404).json({ message: 'Not found' });
  res.json(todo);
};

exports.updateTodo = async (req, res) => {
  const todo = await Todo.findOneAndUpdate(
    { _id: req.params.id, user: req.user._id },
    req.body,
    { new: true }
  );
  res.json(todo);
};

exports.deleteTodo = async (req, res) => {
  await Todo.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  res.json({ message: 'Deleted' });
};
