const User = require('../models/User');
const bcrypt = require('bcryptjs');

exports.register = async (req, res) => {
  console.log('✅ Inside register function', req.body);  

  try {
    const { email, password } = req.body;
    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ email, password: hashed });

    console.log('🙌 User created:', user);  
    res.status(201).json({ message: 'User registered' });
  } catch (err) {
    console.error('❌ Register Error:', err.message);  
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

exports.login = async (req, res) => {
  res.json({ message: 'Login coming soon' });
};

exports.getProfile = async (req, res) => {
  res.json({ message: 'Profile coming soon' });
};
